package com.jjemsboys.socialscience.studyapp.ui.screens.home

import android.content.Intent
import android.view.HapticFeedbackConstants
import androidx.compose.ui.platform.LocalContext
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import com.jjemsboys.socialscience.studyapp.ui.components.LocalAppFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.ChapterRepository
import com.jjemsboys.socialscience.studyapp.ui.components.AnimatedCounter
import com.jjemsboys.socialscience.studyapp.ui.components.PremiumCard
import com.jjemsboys.socialscience.studyapp.ui.components.performAppFeedback
import com.jjemsboys.socialscience.studyapp.ui.theme.HeroGradientStartDark
import com.jjemsboys.socialscience.studyapp.ui.theme.HeroGradientEndDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(nav: NavController) {
    val view = LocalView.current
    val appFeedback = LocalAppFeedback.current
    val chapters = remember { ChapterRepository.chapters }
    val totalQA = remember { chapters.sumOf { it.qa.size } }
    val totalMCQ = remember { chapters.sumOf { it.mcq.size } }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        "Social Science",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        // FIX: Added contentPadding bottom = 100.dp to prevent black cutoff behind nav bar
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            item {
                Text(
                    "Quick Actions",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            item {
                QuickActionsGrid(nav)
            }

            item {
                Text(
                    "Others",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            item {
                StudyToolsCard(nav, LocalContext.current)
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun HeroCard(totalChapters: Int, totalQA: Int, totalMCQ: Int) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .shadow(16.dp, RoundedCornerShape(28.dp))
            .clip(RoundedCornerShape(28.dp))
            .background(
                // FIX: Better gradient colors
                Brush.linearGradient(
                    colors = listOf(
                        HeroGradientStartDark,
                        HeroGradientEndDark
                    )
                )
            )
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    "Ready to learn?",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Master your social science curriculum",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatItem(label = "Chapters", value = totalChapters)
                StatItem(label = "Q&A", value = totalQA)
                StatItem(label = "MCQs", value = totalMCQ)
            }
        }
    }
}

@Composable
fun StatItem(label: String, value: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        AnimatedCounter(target = value, style = MaterialTheme.typography.headlineSmall, color = Color.White)
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = Color.White.copy(alpha = 0.8f)
        )
    }
}

private data class QuickAction(
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val route: String,
    val summary: String
)

@Composable
fun QuickActionsGrid(nav: NavController) {
    val view = LocalView.current
    val appFeedback = LocalAppFeedback.current
    val actions = listOf(
        QuickAction("Quiz", Icons.Default.Help, "quiz", "Test your knowledge with fun quizzes."),
        QuickAction("Test", Icons.Default.Description, "test", "Take tests and check your score."),
        QuickAction("Flashcards", Icons.Default.Style, "flashcard", "Learn quickly with flashcards."),
        QuickAction("Saved", Icons.Default.Bookmark, "saved", "Access your saved study items anytime.")
    )

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        actions.forEach { action ->
            PremiumCard(
                onClick = {
                    view.performAppFeedback(appFeedback, HapticFeedbackConstants.CONFIRM)
                    nav.navigateToSingleTop(action.route)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = action.icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = action.label,
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 15.sp),
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = action.summary,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ChapterMiniCard(chapter: com.jjemsboys.socialscience.studyapp.data.Chapter, onClick: () -> Unit) {
    val subjectColor = when (chapter.subject.lowercase()) {
        "geography" -> Color(0xFF3B82F6)
        "history" -> Color(0xFFEF4444)
        "civics" -> Color(0xFF10B981)
        "economics" -> Color(0xFFF59E0B)
        else -> MaterialTheme.colorScheme.primary
    }

    PremiumCard(
        onClick = onClick,
        modifier = Modifier.width(260.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(subjectColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = chapter.subtitle.filter { it.isDigit() }.take(2),
                        style = MaterialTheme.typography.titleMedium,
                        color = subjectColor,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = chapter.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = chapter.subject,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { 0f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = subjectColor,
                trackColor = subjectColor.copy(alpha = 0.1f)
            )
        }
    }
}

@Composable
fun StudyToolsCard(nav: NavController, context: android.content.Context) {
    val view = LocalView.current
    val appFeedback = LocalAppFeedback.current
    PremiumCard(modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            ToolRow(
                icon = Icons.Default.Search,
                title = "Global Search",
                desc = "Search across all chapters",
                onClick = {
                    view.performAppFeedback(appFeedback, HapticFeedbackConstants.CONFIRM)
                    nav.navigateToSingleTop("search")
                }
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ToolRow(
                icon = Icons.Default.Share,
                title = "Share App",
                desc = "Invite friends to study",
                onClick = {
                    view.performAppFeedback(appFeedback, HapticFeedbackConstants.CONFIRM)
                    val shareIntent = Intent().apply {
                        action = Intent.ACTION_SEND
                        putExtra(Intent.EXTRA_TEXT, "Check out this awesome Social Science study app! Perfect for mastering your curriculum. Download now: https://socialscienceapp.gt.tc/")
                        type = "text/plain"
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share Social Science App"))
                }
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            ToolRow(
                icon = Icons.Default.Settings,
                title = "Settings",
                desc = "Customize your experience",
                onClick = {
                    view.performAppFeedback(appFeedback, HapticFeedbackConstants.CONFIRM)
                    nav.navigateToSingleTop("settings")
                }
            )
        }
    }

}

private fun NavController.navigateToSingleTop(route: String) {
    navigate(route) {
        popUpTo(graph.startDestinationId) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun ToolRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = desc,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
