package com.jjemsboys.socialscience.studyapp.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * The app uses the platform system font (Roboto) rather than a bundled face, but leans on
 * an iOS Human-Interface-Guidelines-style type scale: a 17sp reading body (larger than the
 * Material default), tight negative tracking on large titles, and a clear weight hierarchy.
 * [scale] lets Settings offer a Small / Default / Large text-size preference that resizes
 * every style in the app consistently.
 */
val AppFontFamily = FontFamily.Default

fun appTypography(scale: Float = 1f): Typography {
    fun size(value: Int) = (value * scale).sp
    return Typography(
        displayLarge = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = size(34),
            lineHeight = size(40),
            letterSpacing = (-0.4).sp,
        ),
        displayMedium = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = size(30),
            lineHeight = size(36),
            letterSpacing = (-0.3).sp,
        ),
        displaySmall = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = size(26),
            lineHeight = size(32),
            letterSpacing = (-0.2).sp,
        ),
        headlineLarge = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = size(28),
            lineHeight = size(34),
            letterSpacing = (-0.2).sp,
        ),
        headlineMedium = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = size(22),
            lineHeight = size(28),
            letterSpacing = (-0.1).sp,
        ),
        headlineSmall = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = size(20),
            lineHeight = size(25),
            letterSpacing = 0.sp,
        ),
        titleLarge = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = size(17),
            lineHeight = size(22),
            letterSpacing = 0.sp,
        ),
        titleMedium = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = size(16),
            lineHeight = size(21),
            letterSpacing = 0.sp,
        ),
        titleSmall = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = size(14),
            lineHeight = size(18),
            letterSpacing = 0.1.sp,
        ),
        bodyLarge = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.Normal,
            fontSize = size(17),
            lineHeight = size(24),
            letterSpacing = 0.sp,
        ),
        bodyMedium = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.Normal,
            fontSize = size(15),
            lineHeight = size(21),
            letterSpacing = 0.sp,
        ),
        bodySmall = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.Normal,
            fontSize = size(13),
            lineHeight = size(18),
            letterSpacing = 0.1.sp,
        ),
        labelLarge = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = size(15),
            lineHeight = size(20),
            letterSpacing = 0.1.sp,
        ),
        labelMedium = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = size(12),
            lineHeight = size(16),
            letterSpacing = 0.2.sp,
        ),
        labelSmall = TextStyle(
            fontFamily = AppFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = size(11),
            lineHeight = size(14),
            letterSpacing = 0.2.sp,
        ),
    )
}
