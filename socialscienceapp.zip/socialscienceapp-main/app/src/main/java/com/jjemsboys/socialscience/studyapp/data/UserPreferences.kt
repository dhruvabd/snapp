package com.jjemsboys.socialscience.studyapp.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore("jjems_prefs")

/**
 * A single past quiz/test attempt, persisted as a delimited string inside a
 * [androidx.datastore.preferences.core.stringSetPreferencesKey] so no extra JSON dependency
 * is required.
 */
data class QuizAttempt(
    val chapterId: String,
    val chapterName: String,
    val mode: String, // "quiz" or "test"
    val score: Int,
    val total: Int,
    val timestamp: Long,
) {
    val percent: Int get() = if (total == 0) 0 else (score * 100) / total

    fun encode(): String =
        listOf(chapterId, chapterName, mode, score, total, timestamp).joinToString(SEP) {
            it.toString().replace(SEP, " ")
        }

    companion object {
        private const val SEP = "§"

        fun parse(raw: String): QuizAttempt? {
            val parts = raw.split(SEP)
            if (parts.size != 6) return null
            return try {
                QuizAttempt(
                    chapterId = parts[0],
                    chapterName = parts[1],
                    mode = parts[2],
                    score = parts[3].toInt(),
                    total = parts[4].toInt(),
                    timestamp = parts[5].toLong(),
                )
            } catch (e: NumberFormatException) {
                null
            }
        }
    }
}

class UserPreferences(private val context: Context) {
    companion object {
        private val SAVED_QA = stringSetPreferencesKey("saved_qa")
        private val KNOWN_QA = stringSetPreferencesKey("known_qa")
        private val COMPLETED_CHAPTERS = stringSetPreferencesKey("completed_chapters")
        private val DARK_MODE = booleanPreferencesKey("dark_mode")
        private val TEXT_SCALE = floatPreferencesKey("text_scale")
        private val LAST_CHAPTER = stringPreferencesKey("last_chapter")
        private val QUIZ_HISTORY = stringSetPreferencesKey("quiz_history")
        private const val NOTE_PREFIX = "note_"
    }

    val savedQa: Flow<Set<String>> = context.dataStore.data.map { it[SAVED_QA] ?: emptySet() }
    val knownQa: Flow<Set<String>> = context.dataStore.data.map { it[KNOWN_QA] ?: emptySet() }
    val completedChapters: Flow<Set<String>> =
        context.dataStore.data.map { it[COMPLETED_CHAPTERS] ?: emptySet() }

    // null = "follow system", otherwise explicit light/dark override.
    val isDarkMode: Flow<Boolean?> = context.dataStore.data.map { it[DARK_MODE] }

    val textScale: Flow<Float> = context.dataStore.data.map { it[TEXT_SCALE] ?: 1f }

    val lastChapterId: Flow<String?> = context.dataStore.data.map { it[LAST_CHAPTER] }

    val quizHistory: Flow<List<QuizAttempt>> = context.dataStore.data.map { prefs ->
        (prefs[QUIZ_HISTORY] ?: emptySet())
            .mapNotNull { QuizAttempt.parse(it) }
            .sortedByDescending { it.timestamp }
    }

    fun note(chapterId: String): Flow<String> =
        context.dataStore.data.map { it[stringPreferencesKey(NOTE_PREFIX + chapterId)] ?: "" }

    suspend fun setNote(chapterId: String, text: String) {
        context.dataStore.edit { prefs ->
            prefs[stringPreferencesKey(NOTE_PREFIX + chapterId)] = text
        }
    }

    suspend fun toggleSaveQA(qaId: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[SAVED_QA] ?: emptySet()
            prefs[SAVED_QA] = if (current.contains(qaId)) current - qaId else current + qaId
        }
    }

    suspend fun toggleKnownQA(qaId: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[KNOWN_QA] ?: emptySet()
            prefs[KNOWN_QA] = if (current.contains(qaId)) current - qaId else current + qaId
        }
    }

    suspend fun toggleCompleteChapter(chapterId: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[COMPLETED_CHAPTERS] ?: emptySet()
            prefs[COMPLETED_CHAPTERS] =
                if (current.contains(chapterId)) current - chapterId else current + chapterId
        }
    }

    suspend fun setDarkMode(enable: Boolean?) {
        context.dataStore.edit { prefs ->
            if (enable == null) prefs.remove(DARK_MODE) else prefs[DARK_MODE] = enable
        }
    }

    suspend fun setTextScale(scale: Float) {
        context.dataStore.edit { prefs -> prefs[TEXT_SCALE] = scale }
    }

    suspend fun setLastChapter(chapterId: String) {
        context.dataStore.edit { prefs -> prefs[LAST_CHAPTER] = chapterId }
    }

    suspend fun addQuizAttempt(attempt: QuizAttempt) {
        context.dataStore.edit { prefs ->
            val current = prefs[QUIZ_HISTORY] ?: emptySet()
            prefs[QUIZ_HISTORY] = current + attempt.encode()
        }
    }

    suspend fun resetProgress() {
        context.dataStore.edit { prefs ->
            prefs.remove(SAVED_QA)
            prefs.remove(KNOWN_QA)
            prefs.remove(COMPLETED_CHAPTERS)
            prefs.remove(QUIZ_HISTORY)
            prefs.remove(LAST_CHAPTER)
        }
    }
}
