@file:OptIn(ExperimentalMaterial3Api::class)

package com.jjemsboys.socialscience.studyapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.UserPreferences
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(navController: NavController, prefs: UserPreferences) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val darkModeSetting by prefs.isDarkMode.collectAsState(initial = null)
    val textScale by prefs.textScale.collectAsState(initial = 1f)
    val savedIds by prefs.savedQa.collectAsState(initial = emptySet())
    val completedIds by prefs.completedChapters.collectAsState(initial = emptySet())

    val themeIndex = when (darkModeSetting) {
        null -> 0
        false -> 1
        true -> 2
    }
    val textSizeIndex = when {
        textScale <= 0.95f -> 0
        textScale >= 1.1f -> 2
        else -> 1
    }

    var showResetDialog by remember { mutableStateOf(false) }

    val versionName = remember {
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "1.0"
        } catch (e: Exception) {
            "1.0"
        }
    }

    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            LargeTopAppBar(
                title = { Text("Settings") },
                scrollBehavior = scrollBehavior,
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    scrolledContainerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
        bottomBar = { AppBottomBar(navController, "settings") },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            item {
                SectionHeader(title = "Appearance", modifier = Modifier.padding(horizontal = 0.dp))
                SettingsGroup {
                    Column(Modifier.padding(16.dp)) {
                        Text("Theme", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
                        Spacer(Modifier.height(10.dp))
                        SegmentedControl(
                            options = listOf("System", "Light", "Dark"),
                            selectedIndex = themeIndex,
                            onSelect = { index ->
                                val newValue: Boolean? = when (index) {
                                    1 -> false
                                    2 -> true
                                    else -> null
                                }
                                scope.launch { prefs.setDarkMode(newValue) }
                            },
                        )
                    }
                    SettingsDivider()
                    Column(Modifier.padding(16.dp)) {
                        Text("Text Size", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
                        Spacer(Modifier.height(10.dp))
                        SegmentedControl(
                            options = listOf("Small", "Default", "Large"),
                            selectedIndex = textSizeIndex,
                            onSelect = { index ->
                                val newScale = when (index) {
                                    0 -> 0.9f
                                    2 -> 1.15f
                                    else -> 1f
                                }
                                scope.launch { prefs.setTextScale(newScale) }
                            },
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
            }

            item {
                SectionHeader(title = "Study Data", modifier = Modifier.padding(horizontal = 0.dp))
                SettingsGroup {
                    SettingsRow(
                        title = "Saved Items",
                        icon = Icons.Filled.Bookmark,
                        onClick = { navController.navigate("saved") },
                        trailing = {
                            Text("${savedIds.size}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        },
                    )
                    SettingsDivider()
                    SettingsRow(
                        title = "Completed Chapters",
                        icon = Icons.Filled.CheckCircle,
                        onClick = { navController.navigate("chapters") },
                        trailing = {
                            Text("${completedIds.size}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        },
                    )
                    SettingsDivider()
                    SettingsRow(
                        title = "Reset All Progress",
                        icon = Icons.Filled.Refresh,
                        iconTint = MaterialTheme.colorScheme.error,
                        titleColor = MaterialTheme.colorScheme.error,
                        onClick = { showResetDialog = true },
                    )
                }
                Spacer(Modifier.height(24.dp))
            }

            item {
                SectionHeader(title = "About", modifier = Modifier.padding(horizontal = 0.dp))
                SettingsGroup {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Filled.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("Social Science", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                            Text("Version $versionName", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    SettingsDivider()
                    SettingsRow(
                        title = "Built for focused, offline studying",
                        icon = Icons.Filled.Info,
                    )
                }
            }
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset all progress?") },
            text = { Text("This clears saved items, completed chapters, notes, and quiz history. This can't be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch { prefs.resetProgress() }
                        showResetDialog = false
                    },
                ) {
                    Text("Reset", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) { Text("Cancel") }
            },
        )
    }
}
