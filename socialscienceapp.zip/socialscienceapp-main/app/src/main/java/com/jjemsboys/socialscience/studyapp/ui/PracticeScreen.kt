@file:OptIn(ExperimentalMaterial3Api::class)

package com.jjemsboys.socialscience.studyapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.QuizAttempt
import com.jjemsboys.socialscience.studyapp.data.UserPreferences
import java.text.DateFormat
import java.util.Date

@Composable
fun PracticeScreen(navController: NavController, prefs: UserPreferences) {
    val history by prefs.quizHistory.collectAsState(initial = emptyList())
    val recent = history.take(6)

    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            LargeTopAppBar(
                title = { Text("Practice") },
                scrollBehavior = scrollBehavior,
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    scrolledContainerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
        bottomBar = { AppBottomBar(navController, "practice") },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp),
        ) {
            item {
                Column(
                    modifier = Modifier.padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    PracticeModeCard(
                        title = "Quiz",
                        description = "Untimed practice with instant feedback",
                        icon = Icons.Filled.Create,
                        tint = MaterialTheme.colorScheme.primary,
                        onClick = { navController.navigate("quiz") },
                    )
                    PracticeModeCard(
                        title = "Test",
                        description = "30 seconds per question, exam style",
                        icon = Icons.Filled.Timer,
                        tint = MaterialTheme.colorScheme.error,
                        onClick = { navController.navigate("test") },
                    )
                    PracticeModeCard(
                        title = "Flashcards",
                        description = "Flip cards to test quick recall",
                        icon = Icons.Filled.Style,
                        tint = MaterialTheme.colorScheme.tertiary,
                        onClick = { navController.navigate("flashcard") },
                    )
                }
                Spacer(Modifier.height(20.dp))
            }

            item { SectionHeader(title = "Recent Attempts") }

            if (recent.isEmpty()) {
                item {
                    Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                        EmptyState(
                            icon = Icons.Filled.History,
                            title = "No attempts yet",
                            message = "Take a quiz or test to see your results here.",
                        )
                    }
                }
            } else {
                item {
                    Column(
                        modifier = Modifier.padding(horizontal = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        recent.forEach { attempt -> AttemptRow(attempt) }
                    }
                }
            }
        }
    }
}

@Composable
private fun PracticeModeCard(
    title: String,
    description: String,
    icon: ImageVector,
    tint: Color,
    onClick: () -> Unit,
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = null, tint = tint)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.fillMaxWidth()) {
                Text(title, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
                Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AttemptRow(attempt: QuizAttempt) {
    val gradeColor = when {
        attempt.percent >= 70 -> MaterialTheme.colorScheme.tertiary
        attempt.percent >= 50 -> MaterialTheme.colorScheme.secondary
        else -> MaterialTheme.colorScheme.error
    }
    val dateLabel = remember(attempt.timestamp) {
        DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(attempt.timestamp))
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(gradeColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
            ) {
                Text("${attempt.percent}%", style = MaterialTheme.typography.labelMedium, color = gradeColor)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.fillMaxWidth()) {
                Text(
                    attempt.chapterName,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "${if (attempt.mode == "test") "Test" else "Quiz"} · ${attempt.score}/${attempt.total} · $dateLabel",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
