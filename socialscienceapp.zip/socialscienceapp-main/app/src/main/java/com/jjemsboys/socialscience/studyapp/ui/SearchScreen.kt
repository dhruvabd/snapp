@file:OptIn(ExperimentalMaterial3Api::class)

package com.jjemsboys.socialscience.studyapp.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.ChapterRepository
import com.jjemsboys.socialscience.studyapp.data.UserPreferences
import kotlinx.coroutines.launch

@Composable
fun SearchScreen(navController: NavController, prefs: UserPreferences) {
    var query by remember { mutableStateOf("") }
    var selectedSubject by remember { mutableStateOf("All") }
    val subjects = remember { listOf("All") + ChapterRepository.chapters.map { it.subject }.distinct() }

    val savedIds by prefs.savedQa.collectAsState(initial = emptySet())
    val scope = rememberCoroutineScope()

    val groups = remember(query, selectedSubject) {
        if (query.isBlank()) {
            emptyList()
        } else {
            ChapterRepository.chapters
                .filter { selectedSubject == "All" || it.subject == selectedSubject }
                .mapNotNull { chapter ->
                    val entries = (chapter.qa.map { Triple(it.id, it.q, it.a) } + chapter.textbook.map { Triple(it.id, it.q, it.a) })
                        .filter { it.second.contains(query, true) || it.third.contains(query, true) }
                    if (entries.isEmpty()) null else chapter to entries
                }
        }
    }
    val totalResults = groups.sumOf { it.second.size }

    Scaffold(
        topBar = {
            DetailTopBar(
                title = "Search",
                onBack = { navController.popBackStack() },
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 0.dp, 16.dp, 24.dp),
        ) {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    placeholder = { Text("Search all chapters…") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    shape = MaterialTheme.shapes.medium,
                )
            }

            if (subjects.size > 2) {
                item {
                    SubjectFilterRow(subjects, selectedSubject, { selectedSubject = it })
                }
            }

            if (query.isBlank()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        EmptyState(
                            icon = Icons.Filled.Search,
                            title = "Search across all chapters",
                            message = "Find any question or answer instantly.",
                        )
                    }
                }
            } else if (totalResults == 0) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        EmptyState(
                            icon = Icons.Filled.SearchOff,
                            title = "No results",
                            message = "Try a different search term or subject.",
                        )
                    }
                }
            } else {
                item {
                    Text(
                        "$totalResults result${if (totalResults == 1) "" else "s"}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp),
                    )
                }
                groups.forEach { (chapter, entries) ->
                    item {
                        SectionHeader(title = "${chapter.title} · ${entries.size}")
                    }
                    items(entries, key = { it.first }) { (id, q, a) ->
                        Box(Modifier.padding(bottom = 10.dp)) {
                            QuestionCard(
                                id = id,
                                question = q,
                                answer = a,
                                isSaved = savedIds.contains(id),
                                onToggleSave = { scope.launch { prefs.toggleSaveQA(id) } },
                                initiallyExpanded = true,
                            )
                        }
                    }
                }
            }
        }
    }
}
