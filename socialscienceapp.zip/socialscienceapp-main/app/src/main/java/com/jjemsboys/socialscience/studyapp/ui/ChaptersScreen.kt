@file:OptIn(ExperimentalMaterial3Api::class)

package com.jjemsboys.socialscience.studyapp.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.ChapterRepository
import com.jjemsboys.socialscience.studyapp.data.UserPreferences

@Composable
fun ChaptersScreen(navController: NavController, prefs: UserPreferences) {
    val completedIds by prefs.completedChapters.collectAsState(initial = emptySet())
    var selectedSubject by remember { mutableStateOf("All") }

    val subjects = remember { listOf("All") + ChapterRepository.chapters.map { it.subject }.distinct() }
    val filtered = remember(selectedSubject) {
        if (selectedSubject == "All") ChapterRepository.chapters
        else ChapterRepository.chapters.filter { it.subject == selectedSubject }
    }

    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            LargeTopAppBar(
                title = { Text("Chapters") },
                actions = {
                    IconButton(onClick = { navController.navigate("search") }) {
                        Icon(Icons.Filled.Search, contentDescription = "Search")
                    }
                },
                scrollBehavior = scrollBehavior,
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    scrolledContainerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
        bottomBar = { AppBottomBar(navController, "chapters") },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(bottom = 24.dp),
        ) {
            if (subjects.size > 2) {
                item {
                    SubjectFilterRow(
                        subjects = subjects,
                        selected = selectedSubject,
                        onSelect = { selectedSubject = it },
                    )
                    Spacer(Modifier.height(4.dp))
                }
            }

            items(filtered, key = { it.id }) { chapter ->
                val isComplete = completedIds.contains(chapter.id)
                Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                    ChapterCard(
                        chapter = chapter,
                        onClick = { navController.navigate("chapter/${chapter.id}") },
                        trailing = {
                            Icon(
                                imageVector = if (isComplete) Icons.Filled.CheckCircle else Icons.Filled.ChevronRight,
                                contentDescription = if (isComplete) "Completed" else null,
                                tint = if (isComplete) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(22.dp),
                            )
                        },
                    )
                }
            }

            if (filtered.isEmpty()) {
                item {
                    EmptyState(
                        icon = Icons.Filled.MenuBook,
                        title = "No chapters here",
                        message = "Try a different subject filter.",
                    )
                }
            }
        }
    }
}
