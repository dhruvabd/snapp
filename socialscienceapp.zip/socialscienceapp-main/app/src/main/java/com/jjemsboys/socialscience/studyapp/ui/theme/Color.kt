package com.jjemsboys.socialscience.studyapp.ui.theme
import androidx.compose.ui.graphics.Color

// Light
val Primary = Color(0xFF2563EB)
val OnPrimary = Color(0xFFFFFFFF)
val PrimaryContainer = Color(0xFFDBEAFE)
val OnPrimaryContainer = Color(0xFF1E3A8A)
val Secondary = Color(0xFF3B82F6)
val OnSecondary = Color(0xFFFFFFFF)
val SecondaryContainer = Color(0xFFBFDBFE)
val OnSecondaryContainer = Color(0xFF1E40AF)
val Tertiary = Color(0xFF0EA5E9)
val OnTertiary = Color(0xFFFFFFFF)
val Background = Color(0xFFF8FAFC)
val OnBackground = Color(0xFF0F172A)
val Surface = Color(0xFFFFFFFF)
val OnSurface = Color(0xFF0F172A)
val SurfaceVariant = Color(0xFFF1F5F9)
val OnSurfaceVariant = Color(0xFF64748B)
val Outline = Color(0xFFCBD5E1)
val Error = Color(0xFFEF4444)
val OnError = Color(0xFFFFFFFF)
val Success = Color(0xFF10B981)
val Warning = Color(0xFFF59E0B)

// Dark
val PrimaryDark = Color(0xFF3B82F6)
val OnPrimaryDark = Color(0xFFFFFFFF)
val PrimaryContainerDark = Color(0xFF1E3A8A)
val OnPrimaryContainerDark = Color(0xFFDBEAFE)
val SecondaryDark = Color(0xFF60A5FA)
val OnSecondaryDark = Color(0xFF0F172A)
val SecondaryContainerDark = Color(0xFF1E40AF)
val OnSecondaryContainerDark = Color(0xFFBFDBFE)
val TertiaryDark = Color(0xFF38BDF8)
val OnTertiaryDark = Color(0xFF0F172A)
val BackgroundDark = Color(0xFF0A0E21)  // FIX: Deeper dark background
val OnBackgroundDark = Color(0xFFF8FAFC)
val SurfaceDark = Color(0xFF141B2D)  // FIX: Better dark surface
val OnSurfaceDark = Color(0xFFF8FAFC)
val SurfaceVariantDark = Color(0xFF1E2340)  // FIX: Better card background
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF2D3568)  // FIX: Subtle borders
val ErrorDark = Color(0xFFEF4444)
val OnErrorDark = Color(0xFFFFFFFF)
val SuccessDark = Color(0xFF34D399)
val WarningDark = Color(0xFFFBBF24)

// FIX: Hero gradient colors
val HeroGradientStart = Color(0xFF4A90E2)
val HeroGradientEnd = Color(0xFF357ABD)
val HeroGradientStartDark = Color(0xFF3B82F6)
val HeroGradientEndDark = Color(0xFF1D4ED8)
