package com.jjemsboys.socialscience.studyapp.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

/**
 * Design tokens for the app.
 *
 * The palette borrows from the iOS system color language (since the brief asked for an
 * "iPhone type" UI) rather than the default Material purple: a single indigo brand tint,
 * a warm gold accent for achievements, and semantic green / red for correct / incorrect
 * feedback. Neutrals follow the iOS "grouped background" convention: a soft gray canvas
 * with pure white (or true black in dark mode) surfaces sitting on top of it.
 */

// Brand
val IndigoLight = Color(0xFF5856D6)
val IndigoDark = Color(0xFF5E5CE6)

// Achievement / highlight accent
val GoldLight = Color(0xFFB8860B)
val GoldDark = Color(0xFFF2B93D)

// Semantic feedback
val SuccessLight = Color(0xFF34C759)
val SuccessDark = Color(0xFF30D158)
val ErrorLight = Color(0xFFFF3B30)
val ErrorDark = Color(0xFFFF453A)
val WarningLight = Color(0xFFFF9500)
val WarningDark = Color(0xFFFF9F0A)

// Subject accents
val GeographyAccentLight = Color(0xFF2F9BD6)
val GeographyAccentDark = Color(0xFF52B4EA)
val HistoryAccentLight = Color(0xFFBF7139)
val HistoryAccentDark = Color(0xFFDB9257)

// Light neutrals (iOS "systemGroupedBackground" family)
val BackgroundLight = Color(0xFFF2F2F7)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEAEAF2)
val OutlineLight = Color(0xFFDDDDE3)
val TextPrimaryLight = Color(0xFF1C1C1E)
val TextSecondaryLight = Color(0xFF6C6C70)
val TextTertiaryLight = Color(0xFFAEAEB2)

// Dark neutrals (true-black canvas, elevated surfaces)
val BackgroundDark = Color(0xFF000000)
val SurfaceDark = Color(0xFF1C1C1E)
val SurfaceVariantDark = Color(0xFF2C2C2E)
val OutlineDark = Color(0xFF3A3A3C)
val TextPrimaryDark = Color(0xFFFFFFFF)
val TextSecondaryDark = Color(0xFF98989D)
val TextTertiaryDark = Color(0xFF6C6C70)

val LightColorScheme = lightColorScheme(
    primary = IndigoLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE3E2FB),
    onPrimaryContainer = Color(0xFF1D1B5C),
    secondary = GoldLight,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFBEBC9),
    onSecondaryContainer = Color(0xFF4A3800),
    tertiary = SuccessLight,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFD4F5DC),
    onTertiaryContainer = Color(0xFF0B3B16),
    background = BackgroundLight,
    onBackground = TextPrimaryLight,
    surface = SurfaceLight,
    onSurface = TextPrimaryLight,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = TextSecondaryLight,
    outline = OutlineLight,
    outlineVariant = Color(0xFFE9E9EF),
    error = ErrorLight,
    onError = Color.White,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
)

val DarkColorScheme = darkColorScheme(
    primary = IndigoDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF373592),
    onPrimaryContainer = Color(0xFFE3E2FB),
    secondary = GoldDark,
    onSecondary = Color(0xFF3D2E00),
    secondaryContainer = Color(0xFF574200),
    onSecondaryContainer = Color(0xFFFBEBC9),
    tertiary = SuccessDark,
    onTertiary = Color(0xFF00390B),
    tertiaryContainer = Color(0xFF0B3B16),
    onTertiaryContainer = Color(0xFFD4F5DC),
    background = BackgroundDark,
    onBackground = TextPrimaryDark,
    surface = SurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondaryDark,
    outline = OutlineDark,
    outlineVariant = Color(0xFF2C2C2E),
    error = ErrorDark,
    onError = Color(0xFF690003),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
)
