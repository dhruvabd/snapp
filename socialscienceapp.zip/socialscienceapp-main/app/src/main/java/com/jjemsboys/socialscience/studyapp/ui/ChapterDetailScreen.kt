@file:OptIn(ExperimentalMaterial3Api::class)

package com.jjemsboys.socialscience.studyapp.ui

import android.content.Intent
import android.net.Uri
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.ChapterRepository
import com.jjemsboys.socialscience.studyapp.data.UserPreferences
import kotlinx.coroutines.launch

@Composable
fun ChapterDetailScreen(navController: NavController, chapterId: String, prefs: UserPreferences) {
    val chapter = remember(chapterId) { ChapterRepository.chapterById(chapterId) }
    var query by remember { mutableStateOf("") }
    var showPreview by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(0) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val savedIds by prefs.savedQa.collectAsState(initial = emptySet())
    val completedIds by prefs.completedChapters.collectAsState(initial = emptySet())
    val savedNote by remember(chapterId) { prefs.note(chapterId) }.collectAsState(initial = "")
    var noteOverride by remember(chapterId) { mutableStateOf<String?>(null) }
    var notesExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(chapterId) {
        prefs.setLastChapter(chapterId)
    }

    if (chapter == null) {
        Scaffold { padding ->
            EmptyState(
                icon = Icons.Filled.ErrorOutline,
                title = "Chapter not found",
                message = "This chapter may have been removed.",
                modifier = Modifier.padding(padding),
            )
        }
        return
    }

    val previewUrl = when (chapter.id) {
        "earth_living_planet" -> "https://drive.google.com/file/d/12kjoZTyZ6nQKtq9ZU3CAeBb7pDsHUwZ_/preview"
        "sources" -> "https://drive.google.com/file/d/1vTqL1Stq5z7JQUNJsL6Mc02SFrEVHb9K/preview"
        else -> ""
    }
    val downloadUrl = when (chapter.id) {
        "earth_living_planet" -> "https://drive.google.com/file/d/12kjoZTyZ6nQKtq9ZU3CAeBb7pDsHUwZ_/view"
        "sources" -> "https://drive.google.com/file/d/1vTqL1Stq5z7JQUNJsL6Mc02SFrEVHb9K/view"
        else -> ""
    }

    val isComplete = completedIds.contains(chapter.id)
    val displayedNote = noteOverride ?: savedNote

    Scaffold(
        topBar = {
            DetailTopBar(
                title = chapter.title,
                subtitle = chapter.subject,
                onBack = { navController.popBackStack() },
                actions = {
                    if (previewUrl.isNotEmpty()) {
                        IconButton(onClick = { showPreview = !showPreview }) {
                            Icon(
                                imageVector = if (showPreview) Icons.Default.Close else Icons.Default.PictureAsPdf,
                                contentDescription = if (showPreview) "Close preview" else "Preview PDF",
                            )
                        }
                    }
                },
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        if (showPreview && previewUrl.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize(),
            ) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            webViewClient = WebViewClient()
                            settings.javaScriptEnabled = true
                            settings.setSupportZoom(true)
                            settings.builtInZoomControls = true
                            settings.displayZoomControls = false
                            settings.cacheMode = WebSettings.LOAD_NO_CACHE
                            settings.domStorageEnabled = true
                            settings.loadWithOverviewMode = true
                            settings.useWideViewPort = true
                            loadUrl(previewUrl)
                        }
                    },
                    modifier = Modifier.fillMaxSize(),
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize(),
                contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item {
                    Card(
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                    ) {
                        Column(Modifier.padding(18.dp)) {
                            AssistChip(
                                onClick = {},
                                enabled = false,
                                label = { Text(chapter.subtitle) },
                                colors = AssistChipDefaults.assistChipColors(
                                    labelColor = subjectColor(chapter.subject),
                                    disabledLabelColor = subjectColor(chapter.subject),
                                ),
                            )
                            Spacer(Modifier.height(10.dp))
                            Text(chapter.title, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurface)
                            Spacer(Modifier.height(6.dp))
                            Text(chapter.desc, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                if (previewUrl.isNotEmpty()) {
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = { showPreview = true },
                                modifier = Modifier.weight(1f),
                                shape = MaterialTheme.shapes.medium,
                            ) {
                                Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Preview PDF")
                            }
                            Button(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(downloadUrl))
                                    context.startActivity(intent)
                                },
                                modifier = Modifier.weight(1f),
                                shape = MaterialTheme.shapes.medium,
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Download")
                            }
                        }
                    }
                }

                item {
                    Card(
                        onClick = { scope.launch { prefs.toggleCompleteChapter(chapter.id) } },
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(
                            containerColor = if (isComplete) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.surface,
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = if (isComplete) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                                contentDescription = null,
                                tint = if (isComplete) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = if (isComplete) "Marked as complete" else "Mark chapter as complete",
                                style = MaterialTheme.typography.bodyLarge,
                                color = if (isComplete) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }

                item {
                    Card(
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { notesExpanded = !notesExpanded },
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Edit, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(10.dp))
                                    Text("My Notes", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                                }
                                Icon(
                                    imageVector = if (notesExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            if (notesExpanded) {
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = displayedNote,
                                    onValueChange = { text ->
                                        noteOverride = text
                                        scope.launch { prefs.setNote(chapterId, text) }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    placeholder = { Text("Write a personal note for this chapter…") },
                                    minLines = 3,
                                    shape = MaterialTheme.shapes.medium,
                                )
                            }
                        }
                    }
                }

                item {
                    SegmentedControl(
                        options = listOf("Q&A", "Textbook Answers"),
                        selectedIndex = selectedTab,
                        onSelect = { selectedTab = it },
                    )
                }

                item {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search in this chapter…") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        singleLine = true,
                        shape = MaterialTheme.shapes.medium,
                    )
                }

                if (selectedTab == 0) {
                    val filtered = remember(query, chapter.id) {
                        chapter.qa.filter { it.q.contains(query, true) || it.a.contains(query, true) }
                    }
                    if (filtered.isEmpty()) {
                        item {
                            EmptyState(icon = Icons.Filled.SearchOff, title = "No matches", message = "Try a different search term.")
                        }
                    } else {
                        items(filtered, key = { it.id }) { qa ->
                            QuestionCard(
                                id = qa.id,
                                question = qa.q,
                                answer = qa.a,
                                isSaved = savedIds.contains(qa.id),
                                onToggleSave = { scope.launch { prefs.toggleSaveQA(qa.id) } },
                            )
                        }
                    }
                } else {
                    val filtered = remember(query, chapter.id) {
                        chapter.textbook.filter { it.q.contains(query, true) || it.a.contains(query, true) }
                    }
                    if (filtered.isEmpty()) {
                        item {
                            EmptyState(icon = Icons.Filled.SearchOff, title = "No matches", message = "Try a different search term.")
                        }
                    } else {
                        items(filtered, key = { it.id }) { tb ->
                            QuestionCard(
                                id = tb.id,
                                question = tb.q,
                                answer = tb.a,
                                isSaved = savedIds.contains(tb.id),
                                onToggleSave = { scope.launch { prefs.toggleSaveQA(tb.id) } },
                                initiallyExpanded = true,
                            )
                        }
                    }
                }
            }
        }
    }
}
