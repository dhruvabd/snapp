package com.jjemsboys.socialscience.studyapp.ui.viewmodel
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jjemsboys.socialscience.studyapp.data.Chapter
import com.jjemsboys.socialscience.studyapp.data.MCQ
import com.jjemsboys.socialscience.studyapp.data.QA
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class QuizResult(
    val score: Int,
    val total: Int,
    val percentage: Int,
    val isPass: Boolean
)

class QuizViewModel : ViewModel() {
    var questions by mutableStateOf<List<MCQ>>(emptyList())
        private set
    var currentIndex by mutableIntStateOf(0)
        private set
    var score by mutableIntStateOf(0)
        private set
    var selectedAnswer by mutableStateOf<Int?>(null)
        private set
    var answered by mutableStateOf(false)
        private set
    var timeLeft by mutableIntStateOf(30)
        private set
    var isTestMode by mutableStateOf(false)
        private set
    var isFinished by mutableStateOf(false)
        private set

    private var timerJob: Job? = null

    fun setupQuiz(chapterId: String, mode: String, allChapters: List<Chapter>) {
        isTestMode = mode == "test"
        val base = if (chapterId == "all") {
            allChapters.flatMap { it.mcq }
        } else {
            allChapters.find { it.id == chapterId }?.mcq ?: emptyList()
        }
        questions = base.shuffled().take(10)
        resetState()
    }

    private fun resetState() {
        currentIndex = 0
        score = 0
        selectedAnswer = null
        answered = false
        isFinished = false
        startTimer()
    }

    private fun startTimer() {
        timerJob?.cancel()
        if (!isTestMode) return
        timeLeft = 30
        timerJob = viewModelScope.launch {
            while (timeLeft > 0 && !answered) {
                delay(1000)
                timeLeft--
            }
            if (!answered && !isFinished) {
                submitAnswer(-1)
            }
        }
    }

    fun submitAnswer(index: Int) {
        if (answered || currentIndex >= questions.size) return
        answered = true
        selectedAnswer = index
        if (index == questions[currentIndex].answer) {
            score++
        }
        timerJob?.cancel()
    }

    fun nextQuestion() {
        if (currentIndex < questions.size - 1) {
            currentIndex++
            selectedAnswer = null
            answered = false
            startTimer()
        } else {
            isFinished = true
            timerJob?.cancel()
        }
    }

    fun getResult(): QuizResult {
        val total = questions.size.coerceAtLeast(1)
        val pct = (score * 100) / total
        return QuizResult(score = score, total = total, percentage = pct, isPass = score >= 7)
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}

class FlashcardViewModel : ViewModel() {
    var cards by mutableStateOf<List<QA>>(emptyList())
        private set
    var currentIndex by mutableIntStateOf(0)
        private set
    var isFlipped by mutableStateOf(false)
        private set
    var knownCount by mutableIntStateOf(0)
        private set
    var unknownCount by mutableIntStateOf(0)
        private set
    var isFinished by mutableStateOf(false)
        private set

    fun setupFlashcards(chapterId: String, allChapters: List<Chapter>) {
        cards = if (chapterId == "all") {
            allChapters.flatMap { it.qa }.shuffled()
        } else {
            allChapters.find { it.id == chapterId }?.qa ?: emptyList()
        }
        currentIndex = 0
        isFlipped = false
        knownCount = 0
        unknownCount = 0
        isFinished = false
    }

    fun flip() {
        isFlipped = !isFlipped
    }

    fun markKnown() {
        knownCount++
        nextCard()
    }

    fun markUnknown() {
        unknownCount++
        nextCard()
    }

    private fun nextCard() {
        isFlipped = false
        if (currentIndex < cards.size - 1) {
            currentIndex++
        } else {
            isFinished = true
        }
    }

    val progress: Float
        get() = if (cards.isEmpty()) 0f else (currentIndex + 1).toFloat() / cards.size
}
