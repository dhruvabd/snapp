package com.jjemsboys.socialscience.studyapp.ui.screens.chapters
import com.jjemsboys.socialscience.studyapp.ui.components.performAppFeedback
import android.content.Intent
import android.net.Uri
import android.view.HapticFeedbackConstants
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import com.jjemsboys.socialscience.studyapp.ui.components.LocalAppFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.BookmarkManager
import com.jjemsboys.socialscience.studyapp.data.ChapterRepository
import com.jjemsboys.socialscience.studyapp.data.MCQ
import com.jjemsboys.socialscience.studyapp.data.TextbookQuestion
import com.jjemsboys.socialscience.studyapp.ui.components.ExpandableQACard
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChapterDetailScreen(nav: NavController, id: String) {
    val chapter = ChapterRepository.chapters.find { it.id == id }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val view = LocalView.current
    val appFeedback = LocalAppFeedback.current
    val bookmarkManager = remember { BookmarkManager(context) }
    val savedIds by bookmarkManager.savedQa.collectAsState(initial = emptySet())

    if (chapter == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Chapter not found", style = MaterialTheme.typography.headlineMedium)
        }
        return
    }

    val previewUrl = when (chapter.id) {
        "earth_living_planet" -> "https://drive.google.com/file/d/12kjoZTyZ6nQKtq9ZU3CAeBb7pDsHUwZ_/preview"
        "sources" -> "https://drive.google.com/file/d/1vTqL1Stq5z7JQUNJsL6Mc02SFrEVHb9K/preview"
        else -> ""
    }
    val downloadUrl = when (chapter.id) {
        "earth_living_planet" -> "https://drive.google.com/file/d/12kjoZTyZ6nQKtq9ZU3CAeBb7pDsHUwZ_/view"
        "sources" -> "https://drive.google.com/file/d/1vTqL1Stq5z7JQUNJsL6Mc02SFrEVHb9K/view"
        else -> ""
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var showPreview by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    val tabs = listOf("Notes", "MCQ Practice", "Textbook")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            chapter.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Text(
                            chapter.subject,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    }
                },
                actions = {
                    if (previewUrl.isNotEmpty()) {
                        IconButton(onClick = {
                            view.performAppFeedback(appFeedback, HapticFeedbackConstants.CONFIRM)
                            showPreview = !showPreview
                        }) {
                            Icon(
                                if (showPreview) Icons.Default.Close else Icons.Default.PictureAsPdf,
                                contentDescription = if (showPreview) "Close" else "Preview"
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        floatingActionButton = {
            if (previewUrl.isNotEmpty() && !showPreview) {
                ExtendedFloatingActionButton(
                    onClick = {
                        view.performAppFeedback(appFeedback, HapticFeedbackConstants.CONFIRM)
                        showPreview = true
                    },
                    icon = { Icon(Icons.Default.PictureAsPdf, null) },
                    text = { Text("PDF") },
                    shape = RoundedCornerShape(16.dp),
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    ) { padding ->
        if (showPreview && previewUrl.isNotEmpty()) {
            Column(Modifier.padding(padding).fillMaxSize()) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            webViewClient = WebViewClient()
                            settings.javaScriptEnabled = true
                            settings.setSupportZoom(true)
                            settings.builtInZoomControls = true
                            settings.displayZoomControls = false
                            settings.cacheMode = WebSettings.LOAD_NO_CACHE
                            settings.domStorageEnabled = true
                            settings.loadWithOverviewMode = true
                            settings.useWideViewPort = true
                            loadUrl(previewUrl)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.background,
                    contentColor = MaterialTheme.colorScheme.primary,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            height = 3.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = {
                                view.performAppFeedback(appFeedback, HapticFeedbackConstants.CLOCK_TICK)
                                selectedTab = index
                            },
                            text = { Text(title, fontWeight = if (selectedTab == index) FontWeight.SemiBold else FontWeight.Medium) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                AnimatedContent(
                    targetState = selectedTab,
                    transitionSpec = {
                        fadeIn(tween(300)) togetherWith fadeOut(tween(300))
                    },
                    label = "tab_content"
                ) { tab ->
                    when (tab) {
                        0 -> NotesTab(
                            chapterId = chapter.id,
                            qaList = chapter.qa,
                            savedIds = savedIds,
                            query = query,
                            onQueryChange = { query = it },
                            onToggleSave = { scope.launch { bookmarkManager.toggleSaveQA(it) } }
                        )
                        1 -> McqPracticeTab(mcqList = chapter.mcq)
                        2 -> TextbookTab(textbookList = chapter.textbook)
                    }
                }
            }
        }
    }
}

@Composable
fun NotesTab(
    chapterId: String,
    qaList: List<com.jjemsboys.socialscience.studyapp.data.QA>,
    savedIds: Set<String>,
    query: String,
    onQueryChange: (String) -> Unit,
    onToggleSave: (String) -> Unit
) {
    val filtered = qaList.filter {
        it.q.contains(query, ignoreCase = true) || it.a.contains(query, ignoreCase = true)
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search notes...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
        }

        itemsIndexed(filtered) { _, qa ->
            ExpandableQACard(
                qa = qa,
                isSaved = savedIds.contains(qa.id),
                onToggleSave = { onToggleSave(qa.id) },
                query = query
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun McqPracticeTab(mcqList: List<MCQ>) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        itemsIndexed(mcqList) { index, mcq ->
            McqPracticeCard(index = index + 1, mcq = mcq)
        }
        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun McqPracticeCard(index: Int, mcq: MCQ) {
    var revealed by remember { mutableStateOf(false) }
    var selected by remember { mutableIntStateOf(-1) }
    val view = LocalView.current

    val appFeedback = LocalAppFeedback.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "Q$index",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = mcq.q,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(16.dp))
            mcq.options.forEachIndexed { idx, option ->
                val isCorrect = idx == mcq.answer
                val isSelected = selected == idx
                val bgColor = when {
                    !revealed -> MaterialTheme.colorScheme.surfaceVariant
                    isCorrect -> MaterialTheme.colorScheme.primaryContainer
                    isSelected -> MaterialTheme.colorScheme.errorContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }
                val contentColor = when {
                    !revealed -> MaterialTheme.colorScheme.onSurfaceVariant
                    isCorrect -> MaterialTheme.colorScheme.onPrimaryContainer
                    isSelected -> MaterialTheme.colorScheme.onErrorContainer
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                }

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = bgColor,
                    onClick = {
                        if (!revealed) {
                            view.performAppFeedback(appFeedback, HapticFeedbackConstants.CONFIRM)
                            selected = idx
                            revealed = true
                        }
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${('A' + idx)}. $option",
                            modifier = Modifier.weight(1f),
                            color = contentColor,
                            fontWeight = if (isCorrect && revealed) FontWeight.Bold else FontWeight.Normal
                        )
                        if (revealed && isCorrect) {
                            Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                        } else if (revealed && isSelected && !isCorrect) {
                            Icon(Icons.Default.Cancel, null, tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TextbookTab(textbookList: List<TextbookQuestion>) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        itemsIndexed(textbookList) { index, tq ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Q${index + 1}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = tq.q,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = tq.a,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
