@file:OptIn(ExperimentalMaterial3Api::class)

package com.jjemsboys.socialscience.studyapp.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.ChapterRepository
import com.jjemsboys.socialscience.studyapp.data.UserPreferences
import kotlinx.coroutines.launch

@Composable
fun SavedScreen(navController: NavController, prefs: UserPreferences) {
    val savedIds by prefs.savedQa.collectAsState(initial = emptySet())
    val scope = rememberCoroutineScope()

    val groups = remember(savedIds) {
        ChapterRepository.chapters.mapNotNull { chapter ->
            val entries = (chapter.qa.map { Triple(it.id, it.q, it.a) } + chapter.textbook.map { Triple(it.id, it.q, it.a) })
                .filter { savedIds.contains(it.first) }
            if (entries.isEmpty()) null else chapter to entries
        }
    }
    val totalSaved = groups.sumOf { it.second.size }

    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            LargeTopAppBar(
                title = { Text("Saved") },
                scrollBehavior = scrollBehavior,
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    scrolledContainerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
        bottomBar = { AppBottomBar(navController, "saved") },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        if (totalSaved == 0) {
            Box(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                EmptyState(
                    icon = Icons.Filled.BookmarkBorder,
                    title = "No saved items yet",
                    message = "Tap the bookmark icon on any question to save it here for quick revision.",
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize(),
                contentPadding = PaddingValues(16.dp, 0.dp, 16.dp, 24.dp),
            ) {
                groups.forEach { (chapter, entries) ->
                    item {
                        SectionHeader(title = "${chapter.title} · ${entries.size}")
                    }
                    items(entries, key = { it.first }) { (id, q, a) ->
                        Box(Modifier.padding(bottom = 10.dp)) {
                            QuestionCard(
                                id = id,
                                question = q,
                                answer = a,
                                isSaved = true,
                                onToggleSave = { scope.launch { prefs.toggleSaveQA(id) } },
                            )
                        }
                    }
                }
            }
        }
    }
}
