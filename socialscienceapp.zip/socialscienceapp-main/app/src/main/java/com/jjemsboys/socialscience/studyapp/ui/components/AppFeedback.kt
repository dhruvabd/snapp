package com.jjemsboys.socialscience.studyapp.ui.components
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.feedbackDataStore by preferencesDataStore("feedback_prefs")

data class AppFeedbackState(
    val hapticEnabled: Boolean = false,
    val soundEnabled: Boolean = false
)

val LocalAppFeedback = staticCompositionLocalOf { AppFeedbackState() }

class FeedbackManager(private val context: Context) {
    companion object {
        private val HAPTIC_ENABLED = booleanPreferencesKey("haptic_enabled")
        private val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
    }

    val hapticEnabled: Flow<Boolean> = context.feedbackDataStore.data.map { it[HAPTIC_ENABLED] ?: false }
    val soundEnabled: Flow<Boolean> = context.feedbackDataStore.data.map { it[SOUND_ENABLED] ?: false }

    suspend fun setHapticEnabled(enabled: Boolean) {
        context.feedbackDataStore.edit { prefs ->
            prefs[HAPTIC_ENABLED] = enabled
        }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.feedbackDataStore.edit { prefs ->
            prefs[SOUND_ENABLED] = enabled
        }
    }
}

object AppSoundPlayer {
    private var toneGenerator: ToneGenerator? = null

    fun playClick() {
        if (toneGenerator == null) {
            toneGenerator = ToneGenerator(AudioManager.STREAM_SYSTEM, 80)
        }
        toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 60)
    }
}

fun View.performAppFeedback(
    feedback: AppFeedbackState,
    hapticConstant: Int = HapticFeedbackConstants.CONFIRM
) {
    if (feedback.hapticEnabled) {
        performHapticFeedback(hapticConstant)
    }
    if (feedback.soundEnabled) {
        AppSoundPlayer.playClick()
    }
}
