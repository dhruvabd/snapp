package com.jjemsboys.socialscience.studyapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.jjemsboys.socialscience.studyapp.data.UserPreferences
import com.jjemsboys.socialscience.studyapp.ui.*
import com.jjemsboys.socialscience.studyapp.ui.theme.SocialScienceTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            val context = LocalContext.current
            val prefs = remember { UserPreferences(context) }
            val systemDark = isSystemInDarkTheme()

            // If no explicit preference has been set yet, follow the system theme.
            val darkModeSetting by prefs.isDarkMode.collectAsState(initial = null)
            val finalDarkMode = darkModeSetting ?: systemDark
            val textScale by prefs.textScale.collectAsState(initial = 1f)

            SocialScienceTheme(darkTheme = finalDarkMode, textScale = textScale) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppNav(prefs)
                }
            }
        }
    }
}

@Composable
fun AppNav(prefs: UserPreferences) {
    val nav: NavController = rememberNavController()

    NavHost(
        navController = nav,
        startDestination = "home",
        enterTransition = { fadeIn(animationSpec = tween(220)) + slideInHorizontally(initialOffsetX = { it / 12 }) },
        exitTransition = { fadeOut(animationSpec = tween(180)) },
        popEnterTransition = { fadeIn(animationSpec = tween(220)) },
        popExitTransition = { fadeOut(animationSpec = tween(180)) + slideOutHorizontally(targetOffsetX = { it / 12 }) },
    ) {
        // Root tabs
        composable("home") { HomeScreen(nav, prefs) }
        composable("chapters") { ChaptersScreen(nav, prefs) }
        composable("practice") { PracticeScreen(nav, prefs) }
        composable("saved") { SavedScreen(nav, prefs) }
        composable("settings") { SettingsScreen(nav, prefs) }

        // Chapter detail
        composable("chapter/{id}") { backStack ->
            ChapterDetailScreen(nav, backStack.arguments?.getString("id") ?: "", prefs)
        }

        // Search
        composable("search") { SearchScreen(nav, prefs) }

        // Quiz / Test
        composable("quiz") { QuizSelectorScreen(nav, mode = "quiz") }
        composable("test") { QuizSelectorScreen(nav, mode = "test") }
        composable("quiz_play/{id}/{mode}") { backStack ->
            val id = backStack.arguments?.getString("id") ?: ""
            val mode = backStack.arguments?.getString("mode") ?: "quiz"
            QuizScreen(nav, prefs, id, mode)
        }

        // Flashcards
        composable("flashcard") { FlashcardSelectorScreen(nav) }
        composable("flashcard_play/{id}") { backStack ->
            FlashcardScreen(nav, prefs, backStack.arguments?.getString("id") ?: "")
        }
    }
}
