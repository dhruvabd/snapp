@file:OptIn(ExperimentalMaterial3Api::class)

package com.jjemsboys.socialscience.studyapp.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.jjemsboys.socialscience.studyapp.data.ChapterRepository
import com.jjemsboys.socialscience.studyapp.data.QuizAttempt
import com.jjemsboys.socialscience.studyapp.data.UserPreferences
import kotlinx.coroutines.delay

@Composable
fun QuizSelectorScreen(navController: NavController, mode: String) {
    var selectedSubject by remember { mutableStateOf("All") }
    val subjects = remember { listOf("All") + ChapterRepository.chapters.map { it.subject }.distinct() }
    val filteredChapters = remember(selectedSubject) {
        if (selectedSubject == "All") ChapterRepository.chapters
        else ChapterRepository.chapters.filter { it.subject == selectedSubject }
    }
    val allCount = remember { ChapterRepository.chapters.sumOf { it.mcq.size } }

    Scaffold(
        topBar = {
            DetailTopBar(
                title = if (mode == "test") "Test Mode" else "Practice Quiz",
                subtitle = if (mode == "test") "Timed · one attempt" else "Untimed · instant feedback",
                onBack = { navController.popBackStack() },
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp),
        ) {
            if (subjects.size > 2) {
                item {
                    SubjectFilterRow(subjects, selectedSubject, { selectedSubject = it })
                    Spacer(Modifier.height(4.dp))
                }
            }

            item {
                Card(
                    onClick = { navController.navigate("quiz_play/all/$mode") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 6.dp),
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.18f)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Filled.Shuffle, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("All Chapters", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onPrimary)
                            Text(
                                "Random mix · $allCount questions available",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f),
                            )
                        }
                    }
                }
            }

            items(filteredChapters, key = { it.id }) { chapter ->
                Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                    ChapterCard(
                        chapter = chapter,
                        onClick = { navController.navigate("quiz_play/${chapter.id}/$mode") },
                        trailing = {
                            Text(
                                "${chapter.mcq.size} Qs",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        },
                    )
                }
            }
        }
    }
}

@Composable
fun QuizScreen(navController: NavController, prefs: UserPreferences, chapterId: String, mode: String) {
    val allMcqs = remember(chapterId) {
        if (chapterId == "all") ChapterRepository.chapters.flatMap { it.mcq }
        else ChapterRepository.chapterById(chapterId)?.mcq ?: emptyList()
    }
    val chapterName = remember(chapterId) {
        if (chapterId == "all") "All Chapters" else ChapterRepository.chapterById(chapterId)?.title ?: "Quiz"
    }

    var restartKey by remember { mutableStateOf(0) }
    val questionCount = remember(allMcqs) { minOf(10, allMcqs.size) }
    val questions = remember(chapterId, restartKey) { allMcqs.shuffled().take(questionCount) }

    var currentIdx by remember(restartKey) { mutableStateOf(0) }
    var score by remember(restartKey) { mutableStateOf(0) }
    var selectedIdx by remember { mutableStateOf<Int?>(null) }
    var timeLeft by remember { mutableStateOf(30) }
    var answered by remember { mutableStateOf(false) }
    var attemptSaved by remember(restartKey) { mutableStateOf(false) }

    val haptics = LocalHapticFeedback.current

    LaunchedEffect(currentIdx, mode, restartKey) {
        selectedIdx = null
        answered = false
        if (mode == "test") {
            timeLeft = 30
            while (timeLeft > 0 && !answered) {
                delay(1000)
                timeLeft--
            }
            if (!answered && currentIdx < questions.size) {
                currentIdx++
            }
        }
    }

    if (questions.isEmpty()) {
        Scaffold(
            topBar = { DetailTopBar(title = "Quiz", onBack = { navController.popBackStack() }) },
            containerColor = MaterialTheme.colorScheme.background,
        ) { padding ->
            EmptyState(
                icon = Icons.Filled.ErrorOutline,
                title = "No questions available",
                message = "This chapter doesn't have quiz questions yet.",
                modifier = Modifier.padding(padding),
            )
        }
        return
    }

    if (currentIdx >= questions.size) {
        LaunchedEffect(restartKey) {
            if (!attemptSaved) {
                attemptSaved = true
                prefs.addQuizAttempt(
                    QuizAttempt(
                        chapterId = chapterId,
                        chapterName = chapterName,
                        mode = mode,
                        score = score,
                        total = questions.size,
                        timestamp = System.currentTimeMillis(),
                    ),
                )
            }
        }

        val percent = (score * 100) / questions.size
        val gradeLabel: String
        val gradeColor: Color
        when {
            percent >= 90 -> { gradeLabel = "Excellent!"; gradeColor = MaterialTheme.colorScheme.tertiary }
            percent >= 70 -> { gradeLabel = "Great job!"; gradeColor = MaterialTheme.colorScheme.primary }
            percent >= 50 -> { gradeLabel = "Good effort"; gradeColor = MaterialTheme.colorScheme.secondary }
            else -> { gradeLabel = "Keep practicing"; gradeColor = MaterialTheme.colorScheme.error }
        }

        Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(
                    modifier = Modifier
                        .size(96.dp)
                        .clip(CircleShape)
                        .background(gradeColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = gradeColor, modifier = Modifier.size(44.dp))
                }
                Spacer(Modifier.height(20.dp))
                Text(gradeLabel, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.height(8.dp))
                Text(
                    "You scored $score out of ${questions.size}",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text("$percent%", style = MaterialTheme.typography.displaySmall, color = gradeColor)
                Spacer(Modifier.height(32.dp))
                Button(
                    onClick = { restartKey++ },
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium,
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Try Again")
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { navController.popBackStack("practice", inclusive = false) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium,
                ) {
                    Text("Done")
                }
            }
        }
        return
    }

    val question = questions[currentIdx]
    val timerColor = when {
        timeLeft <= 5 -> MaterialTheme.colorScheme.error
        timeLeft <= 15 -> MaterialTheme.colorScheme.secondary
        else -> MaterialTheme.colorScheme.tertiary
    }

    Scaffold(
        topBar = {
            DetailTopBar(
                title = if (mode == "test") "Test" else "Quiz",
                subtitle = chapterName,
                onBack = { navController.popBackStack() },
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(20.dp),
        ) {
            LinearProgressIndicator(
                progress = { currentIdx / questions.size.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
            )
            Spacer(Modifier.height(10.dp))

            if (mode == "test") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "Question ${currentIdx + 1} of ${questions.size}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Timer, contentDescription = null, tint = timerColor, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("${timeLeft}s", style = MaterialTheme.typography.labelLarge, color = timerColor)
                    }
                }
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { timeLeft / 30f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = timerColor,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                )
            } else {
                Text(
                    "Question ${currentIdx + 1} of ${questions.size}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Spacer(Modifier.height(16.dp))
            Text(question.q, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(20.dp))

            question.options.forEachIndexed { idx, option ->
                val targetContainer = when {
                    !answered -> MaterialTheme.colorScheme.surface
                    idx == question.answer -> MaterialTheme.colorScheme.tertiary
                    idx == selectedIdx -> MaterialTheme.colorScheme.error
                    else -> MaterialTheme.colorScheme.surface
                }
                val containerColor by animateColorAsState(targetContainer, label = "optionContainer")
                val targetContent = if (answered && (idx == question.answer || idx == selectedIdx)) {
                    Color.White
                } else {
                    MaterialTheme.colorScheme.onSurface
                }
                val contentColor by animateColorAsState(targetContent, label = "optionContent")

                Card(
                    onClick = {
                        if (!answered) {
                            selectedIdx = idx
                            answered = true
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            if (idx == question.answer) score++
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = containerColor),
                    shape = MaterialTheme.shapes.medium,
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(option, style = MaterialTheme.typography.bodyLarge, color = contentColor, modifier = Modifier.weight(1f))
                        if (answered && idx == question.answer) {
                            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Color.White)
                        }
                    }
                }
            }

            if (answered) {
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = { currentIdx++ },
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium,
                ) {
                    Text(if (currentIdx == questions.size - 1) "Finish" else "Next Question")
                }
            }
        }
    }
}
